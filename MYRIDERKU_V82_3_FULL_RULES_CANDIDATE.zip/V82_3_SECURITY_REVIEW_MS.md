# MYRIDERKU V82.3 — Full Rules Candidate & Security Review

## Status
**CANDIDATE ONLY — NOT PRODUCTION VERIFIED / NOT APPROVED TO PUBLISH**

Tiada sambungan ke Firebase Production, tiada perubahan data, tiada Rules diterbitkan, tiada deployment dan tiada Blaze diaktifkan.

## Source baseline used
- Library file: `database.rules(5).json`
- Materialized source size: 6,145 bytes
- SHA-256: `a1ac7744acb63a6a86c7bdda51fa6957321fcff04d7fd0eadd749723c8a3c5f5`
- This is the latest timestamped Rules file located in the available Library search results (17 Nov 2026, 11:38 UTC). It is **not proof** that it matches the currently published Firebase Console Rules.

## V82.3 change
Added explicit client-side deny rules to these four root nodes:
- `/privatePhoneOtp`
- `/privatePhoneOtpPhoneIndex`
- `/customerPhoneIndex`
- `/customers`

Each has `.read: false` and `.write: false`. Firebase Admin SDK calls made by Cloud Functions bypass RTDB Security Rules, so backend OTP/customer operations remain possible.

## Findings from the source candidate

### Positive controls
- Root `.read` and `.write` are `false` (deny by default).
- `/settings` is restricted to the verified admin email.
- `/orders/$orderId` reads are scoped to the order's `customerUid`, `riderUid`, or verified admin.
- `/vorders/$vendorUid/$orderId` and `/vpayouts/$vendorUid` reads are scoped to the matching vendor UID or verified admin.
- `/proofs/$orderId` and `/proofsP/$orderId` reads are scoped to order rider/customer or verified admin (proofsP excludes customer).
- Client writes to orders, vorders, proofs and payouts are admin-only in this candidate; Cloud Functions Admin SDK writes are not blocked by these client Rules.

### Risks / items needing code-path confirmation before any publish
1. **Order discovery/dispatch:** `/orders/$orderId` only grants a rider read when `riderUid == auth.uid`. If the Rider app queries unassigned orders or pending offers directly from `/orders`, dispatch may stop working. Confirm current Rider app reads and the offer/claim paths before release.
2. **Vendor/Rider parent writes:** owner writes to the complete `/vendors/$uid` and `/riders/$uid` records are allowed when selected sensitive fields remain unchanged. This does not whitelist every other field. A client may still alter unprotected fields such as role-like/profile/payment metadata if those fields exist. Prefer field-level allowlists or server callables for sensitive updates.
3. **FCM token role path:** `/fcmTokens/$role/$uid/$token` permits the authenticated UID to write under any `$role` value when UID matches. Restrict `$role` to the known role names and validate token fields/shape.
4. **Public catalog nodes:** `/vshops`, `/vmenu`, `/shops`, `/hazards`, `/publicConfig`, and `/system/maintenance` have public reads. Ensure these contain public-only fields and no phone, exact private address, payout or internal financial data.
5. **Customer ownership schema:** order read depends on `customerUid`; ensure every new order created by the callable writes the canonical UID to this exact field. Legacy orders missing it will not be readable by Customer under this rule.
6. **Admin identity:** admin access uses verified email equality. Confirm this is the intended admin identity model and that the email account is protected with strong authentication.

## Required tests before publication
- Customer A can read own order but cannot read Customer B's order.
- Assigned Rider can read own order; unrelated Rider cannot.
- Rider dispatch can still discover eligible offers through the intended offer node without granting collection-wide `/orders` reads.
- Vendor can read own vorders only; another vendor cannot.
- Customer/Rider/Vendor cannot read `settings`, `orderContacts` for unrelated orders, or another user's wallet logs.
- All four private nodes deny direct reads/writes for anonymous, Customer, Rider, Vendor and Admin client SDK sessions.
- Customer profile and OTP flows continue through callable/Admin SDK.
- Owner cannot change `approved`, `suspended`, `wallet`, `walletReserved`, `walletLog`, role, payout destination or other privileged fields.
- FCM token writes are limited to valid own role path.
- Public catalog nodes contain no sensitive fields.

## Do not publish yet
The candidate is a merge of the located Library Rules file plus the V82.2 private-node patch. It is not a merge against a verified live Production export. Before publishing, compare it byte-for-byte/semantically with the currently displayed Firebase Console Rules and run RTDB Emulator tests against the exact V82.3 app build.
