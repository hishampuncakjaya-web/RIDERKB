# MYRIDERKU V82.2 — Audit Firebase RTDB Rules & akses data pelanggan

## Status
**STATIC AUDIT / PATCH PREPARED — NOT PRODUCTION APPROVED**

Tiada Rules diterbitkan, tiada data Firebase disentuh, tiada Blaze diaktifkan dan tiada deployment dibuat.

## Skop sumber yang diperiksa
1. Kod `functions/index.js` dan `v81-callables.js` dalam pakej kerja V81.1/V82.1.
2. Fail `database.rules.json` yang pernah diberikan dalam perbualan (versi 120/125 baris).
3. Fail `firebase-rules.json` lama 447 baris dalam Library sebagai rujukan sejarah sahaja — bukan dianggap Rules Production semasa.

## 1. Node peribadi OTP dan akaun
Kod backend menggunakan node berikut:
- `/privatePhoneOtp/{temporaryUid}` — hash OTP, expiry, attempts, message metadata.
- `/privatePhoneOtpPhoneIndex/{phone}` — cooldown per nombor telefon.
- `/customerPhoneIndex/{phone}` — pemetaan nombor telefon kepada UID kanonik.
- `/customers/{uid}` — profil, status sekatan, nombor disahkan dan status profil.

Semua operasi ini dibuat oleh Cloud Functions melalui Firebase Admin SDK. Oleh itu, akses terus daripada aplikasi pelanggan/rider/vendor/admin tidak diperlukan.

Patch minimum yang disediakan menetapkan `.read:false` dan `.write:false` pada keempat-empat node. Firebase Admin SDK masih boleh mengakses node tersebut; RTDB Security Rules tidak menghalang Admin SDK.

## 2. Dapatan pada fail Rules terdahulu

### Dapatan penting
- Fail Rules 120/125 baris yang diperiksa **tidak mengandungi** empat node OTP/customer di atas. Jika fail itu masih menjadi asas Rules, node tersebut tertutup secara lalai kerana root `.read:false` dan `.write:false`, tetapi ia belum menyatakan niat keselamatan secara eksplisit.
- Dalam salah satu versi 120 baris, `/orders/{orderId}` memberi `.read` kepada mana-mana Rider yang `approved == true`, bukan hanya Rider yang ditugaskan. Ini boleh mendedahkan rekod pesanan pelanggan kepada semua Rider diluluskan jika versi itu digunakan.
- Versi 125 baris memberi bacaan `/orders/{orderId}` kepada `customerUid`, `riderUid`, Rider approved dan Admin. Perlu diselaraskan dengan medan sebenar yang digunakan kod semasa (`riderUid` berbanding `assignedRiderUid`) dan aliran tawaran rider.
- Kedua-dua versi lama memberi pemilik sendiri `.write` pada keseluruhan `/vendors/{uid}` atau `/riders/{uid}`. Walaupun terdapat sekatan pada beberapa medan sensitif, kebenaran parent boleh membolehkan perubahan medan profil lain. Pengurusan wallet, approval, role, suspension dan payout mesti kekal server/admin sahaja.
- Fail Rules lama 447 baris bukan baseline yang selamat untuk digabung secara automatik: ia mempunyai beberapa laluan luas seperti bacaan order/proof untuk `auth != null` dan penulisan token customer yang hanya memerlukan authentication. Ia tidak boleh digunakan sebagai pengganti tanpa audit penuh.

## 3. Keputusan patch V82.2

Fail `V82_2_RULES_PRIVATE_NODES_PATCH.json` ialah **patch kandungan sahaja**, bukan fail Rules lengkap. Gabungkan empat blok node itu ke dalam objek `rules` penuh yang benar-benar sedang digunakan selepas membuat backup.

Jangan tampal keseluruhan fail patch ini ke Firebase Console kerana ia akan menggantikan Rules sedia ada dan boleh memutuskan fungsi aplikasi.

## 4. Kawalan backend yang perlu kekal
- OTP mesti dihantar/disahkan melalui callable sahaja.
- Nombor telefon unik melalui transaksi atomik pada `/customerPhoneIndex/{phone}`.
- Profil pelanggan hanya dibaca/ditulis melalui callable yang mengesahkan UID, `phoneVerified`, `profileComplete` dan status akaun.
- Akaun `blocked` tidak boleh membuat pesanan baharu atau mengesahkan penerimaan.
- Rider/Vendor masih boleh menyelesaikan pesanan aktif yang telah diterima walaupun pelanggan kemudian disekat; ini mengelakkan tugasan tergantung.
- Jangan beri klien akses terus kepada hash OTP, indeks telefon atau status sekatan.

## 5. Matriks ujian negatif wajib (belum dijalankan)
1. Anonymous / Customer: baca dan tulis keempat-empat node — DENY.
2. Rider: baca dan tulis keempat-empat node — DENY.
3. Vendor: baca dan tulis keempat-empat node — DENY.
4. Admin melalui client SDK: akses terus ke node OTP/index — DENY; urus pelanggan melalui callable admin sahaja.
5. Cloud Function Admin SDK: operasi OTP, indeks dan profil — ALLOW.
6. Customer blocked: create order dan confirm receipt — DENY.
7. Rider/Vendor pada pesanan aktif sedia ada: status operasi yang dibenarkan — ALLOW.
8. Customer A cuba baca profil Customer B atau indeks telefon — DENY.
9. Pengguna cuba menukar `approved`, `role`, `wallet`, `walletReserved`, `walletLog`, `status=blocked` secara client write — DENY.
10. Dua permintaan OTP serentak bagi nombor sama — hanya satu tuntutan indeks berjaya; cooldown dikuatkuasakan.

## 6. Perkara yang belum boleh disahkan
- Rules yang sedang diterbitkan di Firebase Console sekarang.
- Sama ada fail `database.rules.json` yang ditemui ialah Rules terkini atau salinan lama.
- Ujian Firebase RTDB Emulator, ujian multi-client, dan ujian Meta WhatsApp sebenar.

## Langkah seterusnya untuk lengkapkan merge
Sediakan eksport/copy penuh Rules yang sedang dipaparkan sekarang di Firebase Console > Realtime Database > Rules. Saya akan merge patch V82.2 ke dalam salinan itu, semak keseluruhan kebenaran Customer/Rider/Vendor/Admin dan hasilkan satu fail Rules penuh untuk semakan — tanpa publish.
