MYRIDERKU V83 — Checkout & Payment
Keputusan: TnG + RiderPay; biometrik optional; COD kekal.

Fail:
- V83_CHECKOUT_PAYMENT_SPEC_MS.md — spesifikasi dan pelan integrasi.
- checkout-payment.js — adapter UI fail-closed; tiada simulasi bayaran berjaya.
- createCustomerPaymentIntent.STUB.js.txt — contoh backend fail-closed, bukan untuk deploy.

PENTING: Tiada integrasi merchant TnG, tiada wallet Customer/ledger, dan tiada WebAuthn registration dalam sumber projek. Jangan anggap pembayaran sebenar sudah aktif.
Tiada deploy, tiada Blaze, tiada perubahan Production.
