/* MYRIDERKU Checkout & Payment — V83 integration adapter
 * This module deliberately does NOT simulate successful payment.
 * It expects a trusted backend callable to create and confirm payment intents.
 */
(function (global) {
  "use strict";
  let selectedMethod = "tng";
  let busy = false;

  const $ = (id) => document.getElementById(id);
  const money = (n) => "RM " + (Number(n || 0)).toFixed(2);

  function setStatus(message, kind) {
    const el = $("payment-status");
    if (!el) return;
    el.textContent = message;
    el.dataset.kind = kind || "info";
  }

  function selectPaymentMethod(method) {
    if (!["tng", "riderpay", "cash"].includes(method)) return;
    selectedMethod = method;
    document.querySelectorAll("[data-payment-method]").forEach((card) => {
      const active = card.dataset.paymentMethod === method;
      card.classList.toggle("is-selected", active);
      card.setAttribute("aria-pressed", active ? "true" : "false");
    });
    setStatus(method === "cash"
      ? "Bayar tunai mengikut arahan pesanan."
      : "Kaedah dipilih. Bayaran belum dibuat.", "info");
  }

  async function startPayment(orderId, amount) {
    if (busy) return;
    if (!orderId || !Number.isFinite(Number(amount)) || Number(amount) <= 0) {
      setStatus("Maklumat pesanan atau jumlah bayaran tidak sah.", "error");
      return;
    }
    if (selectedMethod === "cash") {
      setStatus("COD dipilih. Pesanan tertakluk pada pengesahan dan peraturan COD MYRIDERKU.", "info");
      return { method: "cash", status: "pending_cash" };
    }

    const api = global.MYRIDERKU_V81;
    if (!api || typeof api.createPaymentIntent !== "function") {
      setStatus("Modul pembayaran backend belum dipasang. Tiada wang dicaj.", "error");
      return;
    }

    busy = true;
    setStatus("Menyediakan transaksi selamat…", "pending");
    try {
      const result = await api.createPaymentIntent({
        orderId: String(orderId),
        method: selectedMethod,
        amount: Number(amount)
      });

      if (!result || result.ok !== true || !result.paymentId) {
        throw new Error("Transaksi tidak dapat dimulakan.");
      }

      if (selectedMethod === "tng") {
        if (!result.checkoutUrl) {
          throw new Error("Pautan pembayaran TnG belum disediakan oleh penyedia pembayaran.");
        }
        // Open only the URL returned by trusted backend.
        global.location.assign(result.checkoutUrl);
        return result;
      }

      // RiderPay must be completed by a trusted server transaction.
      if (result.status === "paid") {
        setStatus("Bayaran disahkan oleh server.", "success");
        return result;
      }
      setStatus("Transaksi RiderPay sedang diproses. Semak status sebelum membuat bayaran lain.", "pending");
      return result;
    } catch (err) {
      console.error("MYRIDERKU payment error", err);
      setStatus(err && err.message ? err.message : "Pembayaran gagal dimulakan. Tiada status bayaran berjaya direkodkan.", "error");
      return null;
    } finally {
      busy = false;
    }
  }

  // Biometric is optional local user-presence confirmation, never payment proof.
  async function requestBiometricConfirmation() {
    if (!global.PublicKeyCredential || !navigator.credentials) {
      setStatus("Biometrik tidak disokong pada peranti atau pelayar ini. Teruskan dengan pengesahan biasa.", "info");
      return { supported: false, confirmed: false };
    }
    setStatus("Biometrik tersedia, tetapi perlu konfigurasi WebAuthn dan pendaftaran pengguna terlebih dahulu.", "info");
    return { supported: true, configured: false, confirmed: false };
  }

  global.MYRIDERKU_PAYMENT = {
    selectPaymentMethod,
    startPayment,
    requestBiometricConfirmation,
    getSelectedMethod: () => selectedMethod,
    money
  };
})(window);
