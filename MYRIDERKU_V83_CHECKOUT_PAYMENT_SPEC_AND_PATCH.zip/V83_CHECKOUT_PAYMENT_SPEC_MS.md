# MYRIDERKU V83 — Spesifikasi Checkout & Payment

## Keputusan yang disahkan
- Kaedah pembayaran: TnG eWallet + RiderPay.
- Biometrik: pilihan (optional), hanya jika peranti/pelayar menyokong dan pengguna telah mendaftar.
- COD: dikekalkan.
- Had projek: code/spec sahaja. Tiada deploy, tiada Firebase Production changes, tiada Blaze activation.

## Prinsip transaksi
1. UI tidak boleh menukar status kepada `paid` sendiri.
2. Hanya backend selepas pengesahan penyedia pembayaran atau transaksi wallet atomik boleh menetapkan `paymentStatus: "paid"`.
3. Jumlah bayaran diperoleh daripada rekod pesanan di server, bukan jumlah yang dihantar browser.
4. Setiap cubaan pembayaran menggunakan `paymentId` unik dan idempotency key.
5. Webhook mesti mengesahkan tandatangan, merchant/account, currency MYR, order reference dan amaun.
6. Status yang dicadangkan: `unpaid`, `pending`, `paid`, `failed`, `cancelled`, `refunded`, `pending_cash`.
7. Pesanan hanya dihantar ke dispatch selepas polisi pembayaran pesanan dipenuhi. COD kekal melalui aliran COD sedia ada dan tertakluk kepada syarat wallet Rider yang sedia ada.

## Aliran TnG
- Customer pilih TnG.
- Backend membaca pesanan dan amaun muktamad daripada Firebase.
- Backend cipta payment intent dengan penyedia/merchant yang diluluskan.
- Frontend hanya membuka `checkoutUrl` yang dipulangkan backend.
- Penyedia memanggil webhook backend.
- Backend mengesahkan signature dan memadankan amount/currency/order/payment ID.
- Backend mengemas kini rekod pembayaran secara idempotent.
- Frontend menyemak status melalui callable/status listener; jangan percaya return URL sahaja.

**Kebergantungan belum tersedia:** merchant account, payment provider/aggregator yang menyokong TnG eWallet, API credentials, format webhook dan approval.

## Aliran RiderPay
- RiderPay di sini ditakrif sebagai wallet Customer, berasingan daripada wallet Rider.
- Customer pilih RiderPay.
- Backend semak baki boleh guna dan status akaun.
- Backend melaksanakan transaksi atomik: debit wallet + ledger entry + tandakan payment paid.
- Jika baki tidak cukup, transaksi gagal tanpa debit separa.
- Idempotency menghalang debit berganda.
- Refund/reversal hanya melalui transaksi ledger bertentangan; jangan edit sejarah transaksi.

**Kebergantungan belum tersedia:** struktur wallet Customer, proses top-up/funding, ledger dan dasar refund. Jangan guna wallet Rider atau `adminAdjustRiderWallet` untuk Customer.

## Aliran COD
- COD kekal sebagai pilihan.
- `paymentStatus` bukan `paid`; gunakan `pending_cash` atau status kutipan tunai khusus.
- Polisi deposit/kelayakan Rider dan `walletMinCash` sedia ada mesti kekal; tiada perubahan pada formula COD tanpa audit.
- Status COD hanya selesai selepas pengesahan kutipan mengikut aliran operasi yang ditetapkan.

## Biometrik pilihan
- Biometrik tidak mengesahkan pemindahan wang.
- Ia hanya pengesahan kehadiran/persetujuan pengguna pada peranti.
- Gunakan Android BiometricPrompt dalam APK/native wrapper atau WebAuthn dengan pendaftaran credential sebenar.
- Jangan gunakan `simulateSuccessfulScan()` sebagai bukti transaksi.
- Jika tidak disokong, benarkan aliran pengesahan biasa.
- Jangan simpan cap jari atau data biometrik dalam Firebase.

## Data model cadangan
`payments/{paymentId}`:
- `orderId`, `customerUid`, `method`, `amount`, `currency: "MYR"`
- `status`, `provider`, `providerReference`
- `idempotencyKey`, `createdAt`, `updatedAt`, `paidAt`
- jangan simpan nombor kad, OTP, token rahsia atau data biometrik.

`orders/{orderId}`:
- `paymentStatus`, `paymentMethod`, `paymentId`
- `paidAt` hanya diisi server selepas pengesahan sah.
- elak menggantikan `status` penghantaran yang digunakan Rider/Vendor.

`customerWallets/{uid}` dan `customerWalletLedger/{uid}/{entryId}`:
- hanya selepas wallet Customer dan top-up/funding direka.
- client read hanya untuk pemilik pada medan yang dibenarkan; client write deny.
- semua debit/credit oleh Admin SDK/Cloud Functions.

## Security Rules
- Client tidak boleh menulis `payments`, `customerWallets`, `customerWalletLedger` atau `paymentStatus`.
- Rules perlu disepadukan dengan Rules penuh dan diuji Emulator; jangan publish patch sahaja.
- Admin SDK Cloud Functions digunakan untuk semua mutasi kewangan.

## Pemetaan kepada projek sedia ada (semakan statik)
- `customer.html` ialah aliran penghantaran utama dan kini memanggil callable `createCustomerOrder`.
- `customer-shop.html` mempunyai checkout kedai sendiri dan menulis pesanan kedai melalui laluan lama; belum disatukan dengan payment callable.
- `v81-callables.js` belum ada `createPaymentIntent`.
- `functions/index.js` belum mempunyai penyedia TnG atau wallet Customer.
- Oleh itu fail `checkout-payment.js` ialah adapter frontend contoh yang menolak transaksi jika callable belum dipasang; ia bukan pengaktifan pembayaran.
- `createCustomerPaymentIntent.STUB.js.txt` ialah reka bentuk backend fail-closed, bukan kod untuk ditampal/deploy terus.

## Pelaksanaan seterusnya yang diperlukan
1. Sahkan sama ada RiderPay ialah wallet Customer dan tentukan kaedah top-up.
2. Pilih penyedia/merchant rasmi yang menyokong TnG eWallet dan dapatkan spesifikasi integrasi.
3. Tambah backend create intent, webhook, status query, idempotency dan refund.
4. Bentuk Rules penuh dan uji Firebase Emulator bagi semua peranan.
5. UAT TnG sandbox dan RiderPay dengan kes gagal, timeout, duplicate webhook, refund dan baki tidak cukup.
6. Hanya selepas kelulusan eksplisit, rancang deployment. Tiada deployment dalam V83.

## Status
- Keputusan UX: ditetapkan.
- Frontend adapter fail-closed: disediakan.
- Backend TnG live: belum boleh dibuat tanpa provider/merchant.
- RiderPay ledger Customer: belum ada dalam sumber projek yang disemak.
- Biometrik sebenar: belum didaftarkan/diintegrasi.
- COD: dikekalkan; polisi sedia ada tidak diubah.
- Deployment / Blaze / Production: tidak disentuh.
