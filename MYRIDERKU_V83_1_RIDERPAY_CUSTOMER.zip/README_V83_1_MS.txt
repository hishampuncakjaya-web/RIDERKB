MYRIDERKU V83.1 — RiderPay Customer

Candidate code and spec only. Not deployed.
Includes:
- RiderPay Customer callable candidates
- Security Rules snippet (must be merged into full Rules, not pasted as replacement)
- Specification and test matrix

No customer self top-up/provider integration yet. Admin credit only, with reference and ledger.
No Production Rules/data changes, no Blaze activation, no deployment.
