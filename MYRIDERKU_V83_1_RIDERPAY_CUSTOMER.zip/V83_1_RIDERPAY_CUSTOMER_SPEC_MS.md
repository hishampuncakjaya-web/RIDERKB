# MYRIDERKU V83.1 — RiderPay Customer Wallet

## Matlamat
Membina wallet Customer yang berasingan daripada wallet Rider, untuk pembayaran pesanan MYRIDERKU. TnG dan COD tidak diubah dalam patch ini.

## Apa yang disediakan
- `getMyCustomerWallet`: baca baki sendiri sahaja.
- `payCustomerOrderWithRiderPay`: debit atomik dan tandakan order `paymentStatus=paid` hanya selepas transaksi berjaya.
- `adminCreditCustomerWallet`: kredit manual Admin dengan rujukan dan ledger.
- Contoh model data dan Rules.
- Matriks ujian sebelum integrasi.

## Batasan penting
Ini ialah candidate callable code untuk digabung dan diuji, bukan fail `functions/index.js` siap ganti. Ia menganggap helper sedia ada dalam projek (`requireAuth`, `isAdmin`, `money`, `cleanId`, `db`, `REGION`).
Ia menggunakan transaksi root RTDB untuk memastikan debit wallet, ledger, payment dan order status berubah bersama. Untuk skala besar, perlu pertimbangkan pemisahan transaction boundary / reservation model dan ujian contention.
`adminCreditCustomerWallet` ialah kredit manual Admin sahaja. Ia bukan top-up automatik; tiada integrasi FPX/TnG/top-up dibuat. Jangan kredit wallet tanpa bukti dana diterima.
Customer Wallet hanya boleh digunakan selepas Rules dan backend diuji.
## Data
- `customerWallets/{uid}`: `balance`, `reserved`, `updatedAt`
- `customerWalletLedger/{uid}/{entryId}`: append-only entries
- `payments/{paymentId}`: payment metadata
- `customerPaymentIdempotency/{uid_key}`: orderId/paymentId
- `orders/{orderId}`: `paymentMethod`, `paymentId`, `paymentStatus`, `paidAt`

## Rules minimum
Client SDK:
- `.read` wallet hanya pemilik, jika perlu; ledger hanya pemilik.
- `.write:false` untuk customerWallets, customerWalletLedger, payments, customerPaymentIdempotency.
- Client `.write` pada medan `orders.paymentStatus/paymentId/paidAt` mesti ditolak.
Cloud Functions Admin SDK writes bypass RTDB client Rules. Jangan tambah root public write.

## Business controls
- Customer wallet berasingan daripada `riders/{uid}/wallet`.
- Baki dan reserved mesti tidak negatif.
- Bayaran mengambil jumlah daripada order server-side (`customerPayable` jika ada, jika tidak `price`).
- Payment berjaya dan debit wallet dibuat dalam satu transaction.
- Idempotency key diperlukan untuk retry.
- Sudah paid tidak boleh debit semula.
- Blocked customer ditolak.
- Admin credit memerlukan reference dan disimpan dalam ledger.
- Tiada top-up customer sendiri sehingga payment provider rasmi disambung.

## Risiko / perkara wajib disahkan sebelum merge
1. Confirm `orders/{id}.customerUid` adalah canonical Customer UID untuk semua order termasuk customer-shop/vendor orders.
2. Confirm field jumlah sebenar pelanggan (`customerPayable` atau `price`) tepat untuk semua jenis order; customer-shop `vorders` mungkin memerlukan callable berasingan.
3. Semak order status sebenar yang dibenarkan untuk pembayaran. Candidate menerima `baru` atau `menunggu_bayaran`.
4. Confirm status `paymentStatus` dan `status` penghantaran tidak bertindih.
5. Pastikan Rider dispatch hanya menerima order mengikut polisi pembayaran (online paid atau COD eligible).
6. Pastikan refund/reversal direka sebagai ledger credit baru, bukan edit/delete ledger.
7. Root transaction mungkin contention apabila DB membesar; jalankan load/concurrency tests sebelum production.
8. Isu race: customer order callable sedia ada perlu initialize `paymentStatus:"unpaid"` untuk kaedah online. Jangan anggap sudah berlaku sehingga disahkan.

## Ujian wajib
- Customer A tidak boleh baca wallet Customer B.
- Client tidak boleh menulis baki/ledger/payment.
- Customer blocked tidak boleh baca wallet atau membayar.
- Baki cukup: debit tepat sekali, payment paid, ledger satu entry.
- Baki tidak cukup: tiada perubahan pada wallet/order/payment.
- Dua request serentak untuk order sama: satu debit sahaja.
- Retry dengan idempotency key sama: tiada debit berganda.
- Idempotency key digunakan order lain: ditolak.
- Admin credit dengan reference: ledger bertambah dan baki naik.
- Customer tidak boleh memanggil admin credit.
- COD order tidak boleh dibayar sebagai RiderPay jika order state/payment policy melarang.
- Test semua di RTDB Emulator sebelum deployment.

## Status
- Candidate callable source: disediakan.
- Integrasi ke `functions/index.js`: belum dibuat.
- Customer UI: belum disambung.
- Rules: belum diubah.
- Emulator tests: belum dijalankan.
- Production / deploy / Blaze: tidak disentuh.
