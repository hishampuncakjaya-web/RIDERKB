# MYRIDERKU V82.4 — Audit Keserasian Rules dengan Aplikasi

## Skop
Semakan statik dibuat pada salinan projek V81/V82.1 yang tersedia:
- customer.html
- customer-shop.html
- customer-track.html
- rider.html
- vendor.html
- admin.html
- v81-callables.js
- functions/index.js
- V82.3_FULL_RULES_CANDIDATE.json

Ini bukan ujian Firebase Emulator. Tiada panggilan ke Firebase Production.

## Keputusan utama
**V82.3 candidate belum serasi untuk diterbitkan.** Beberapa fungsi aplikasi masih menulis terus ke RTDB sedangkan Rules candidate menolak client writes pada path berkenaan. Terdapat juga isu bacaan koleksi dispatch Rider.

## Matriks ketidakserasian yang ditemui

| Aplikasi / fungsi | Laluan RTDB | Rules candidate | Kesan |
|---|---|---|---|
| Rider memantau senarai pesanan | `orders` (listener/query) | `.read` hanya pada `orders/$orderId` jika `customerUid`/`riderUid` milik pengguna atau Admin | Rider tidak boleh discover order yang belum assigned; query koleksi boleh ditolak |
| Rider simpan foto pickup/drop | `proofs/$id`, `proofsP/$id` | `.write` Admin sahaja | Upload bukti daripada Rider gagal |
| Rider kemas kini flag foto | `orders/$id` | `.write` Admin sahaja | Flag `pickPhoto`/`dropPhoto` gagal |
| Rider kongsi GPS | `orders/$id/riderLoc` | `.write` Admin sahaja | Live location update gagal |
| Customer batalkan order | `orders/$id/status` | `.write` Admin sahaja | Butang batal gagal |
| Customer beri rating | `orders/$id/rating` | `.write` Admin sahaja | Rating gagal |
| Customer-Shop buat pesanan vendor | `vorders/$vendorUid/$id` | `.write` Admin sahaja | Tempahan kedai gagal |
| Customer-Shop menulis had permintaan | `ratelimit/$phoneKey` | Tiada node `ratelimit`; root deny | Multi-location update gagal keseluruhan |
| Customer-Shop membuat delivery order | `orders/$id` + `orderContacts/$id` | `.write` Admin sahaja | Aliran penghantaran dari halaman kedai gagal |
| Admin operasi | `orders`, `orderContacts`, `proofs`, `proofsP`, `settings`, `shops`, `hazards` | Admin email verified | Sebahagian besar dibenarkan; semak peranan dan path sebelum publish |

## Bahagian yang kelihatan serasi
- `customer.html` menggunakan callable `createCustomerOrder` untuk aliran tempahan biasa.
- Customer WhatsApp OTP/profil menggunakan callable functions.
- Rider terima order, status perjalanan dan arrival menggunakan callable bridge.
- Vendor terima/tolak/tanda siap melalui callable bridge.
- Customer pengesahan penerimaan menggunakan `customerConfirmReceipt`.
- Vendor membaca `vorders/$uid` dan `vpayouts/$uid` yang sepadan dengan skop baca Rules.
- Public menu/storefront reads pada `vshops` dan `vmenu` sepadan dengan public read rules.

## Keutamaan pembaikan (jangan longgarkan Rules secara umum)

### P0 — Dispatch Rider
Pilih satu seni bina yang selamat:
1. Server-side callable/stream yang membekalkan hanya order layak untuk Rider; atau
2. Node `riderOffers/$riderUid/$orderId` yang dijana backend, dengan `.read` hanya UID Rider sendiri dan `.write:false` untuk client.
Jangan beri `.read:true` kepada keseluruhan `/orders`.

### P0 — Bukti dan GPS Rider
Pindahkan simpan bukti, flag foto dan lokasi Rider kepada callable/server endpoint yang mengesahkan:
- UID Rider ditugaskan pada order;
- status order membenarkan tindakan itu;
- saiz/jenis bukti sah;
- hanya medan yang dibenarkan dikemas kini.
Jangan buka `.write` seluruh `/orders` atau `/proofs`.

### P0 — Customer-Shop order
Ganti direct multi-location write kepada callable khusus seperti `createVendorOrder` dan `createVendorDeliveryOrder`. Backend mesti semak harga, stok, status kedai, phone/rate-limit, dan cipta rekod `vorders`, `orders`, `orderContacts` secara atomik.

### P1 — Customer cancel/rating
Tambah callable khusus `cancelCustomerOrder` dan `submitCustomerRating`; sahkan customerUid, status order, tempoh dan had rating. Jangan buka write terus pada `orders`.

### P1 — Rat limit
Pindahkan `ratelimit` ke server-side. Jangan tambah public write ke `/ratelimit`.

## Perkara tambahan daripada Rules
- `vendors/$uid` dan `riders/$uid` membenarkan owner write keseluruhan rekod selagi lima medan tertentu tidak berubah. Ini masih terlalu luas; field allowlist/callables diperlukan untuk profile edits.
- `fcmTokens/$role/$uid/$token` tidak menghadkan `$role` kepada role yang dibenarkan.
- `orders/$orderId` read condition bergantung pada `customerUid` dan `riderUid`; rekod lama tanpa `customerUid` tidak boleh dibaca oleh Customer.
- `reports` membenarkan pengguna mencipta report dengan `uid` sendiri; bentuk data perlu disahkan.
- Admin console membuat beberapa direct writes. Rules membenarkannya hanya apabila email admin verified; semak Firebase Auth session sebenar sebelum UAT.

## Cadangan urutan V82.5
1. Reka callable `createVendorOrder` dan `createVendorDeliveryOrder`.
2. Reka callable Rider proof + GPS.
3. Reka callable Customer cancel + rating.
4. Reka node Rider offers server-generated.
5. Kemas kini front-end supaya tiada direct writes ke protected nodes.
6. Jalankan RTDB Emulator rules tests untuk setiap role dan negative cases.
7. Bandingkan candidate dengan Rules sebenar dalam Firebase Console sebelum sebarang publish.

## Status
- Static source scan: selesai.
- JSON parse: lulus.
- Firebase Emulator: belum dijalankan.
- Production Rules: tidak diubah.
- Production data: tidak diubah.
- Deployment / Blaze: tidak dilakukan.

**Kesimpulan: Jangan publish V82.3 candidate lagi.** Pembaikan perlu dibuat pada app/callable supaya keselamatan tidak dikorbankan demi membolehkan UI berfungsi.
